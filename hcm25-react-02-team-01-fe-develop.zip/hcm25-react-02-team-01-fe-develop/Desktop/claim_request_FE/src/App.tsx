import "./App.css";
import TableDraftPage from "./pages/TableDraftPage";
import { Router } from "./routers";

function App() {
  return (
    <>
      {/* <Router /> */}
      <Router />
    </>
  );
}

export default App;
