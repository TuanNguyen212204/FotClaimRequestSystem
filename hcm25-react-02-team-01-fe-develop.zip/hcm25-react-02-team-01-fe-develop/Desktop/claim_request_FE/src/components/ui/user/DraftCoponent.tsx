const DraftCoponent = () => {
  return <div>Draft</div>;
};

export default DraftCoponent;
