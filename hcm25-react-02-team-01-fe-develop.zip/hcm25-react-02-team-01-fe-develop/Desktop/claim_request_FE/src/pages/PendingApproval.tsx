import { PendingComponent } from "../components/ui/approve/PendingApproval";

export const PendingApproval:React.FC = () => {
  return (
    <div>
      <PendingComponent />
    </div>
  );
};
