import { UserInfoComponent } from "@components/ui/user/UserInfoComponent";

export const UserInfo = () => {
  return (
    <div>
      <UserInfoComponent />
    </div>
  );
};
