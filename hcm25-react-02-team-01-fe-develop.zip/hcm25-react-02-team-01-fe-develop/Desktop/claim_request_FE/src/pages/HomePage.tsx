import Header from "../components/ui/header/Header";
import { Sidebar } from "../components/ui/sidebar/Sidebar";

export const HomePage = () => {
  return (
    <div>
       {/* <Header />
       <Sidebar /> */}
    </div>
  );
};
