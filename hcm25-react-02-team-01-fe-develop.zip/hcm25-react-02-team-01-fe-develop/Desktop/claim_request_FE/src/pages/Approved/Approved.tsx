import ApprovedFinanceComponent from "../../components/ui/finance/ApprovedFinanceComponent";

export const Approved: React.FC = () => {
  return (
    <div>
      <ApprovedFinanceComponent />
    </div>
  );
};

export default Approved;
